<?php

$columns = array(
	'one_third' => 'One Third',
	'one_third_last' => 'One Third Last',
	'two_third' => 'Two Thirds',
	'two_third_last' => 'Two Thirds Last',
	'one_half' => 'One Half',
	'one_half_last' => 'One Half Last',
	'one_fourth' => 'One Fourth Last',
	'three_fourth' => 'Three Fourth',
	'three_fourth_last' => 'Three Fourth Last',
	'one_fifth' => 'One Fifth',
	'one_fifth_last' => 'One Fifth Last',
	'two_fifth' => 'Two Fifth',
	'two_fifth_last' => 'Two Fifth Last',
	'three_fifth' => 'Three Fifth',
	'three_fifth_last' => 'Three Fifth Last',
	'four_fifth' => 'Four Fifth',
	'four_fifth_last' => 'Four Fifth Last',
	'one_sixth' => 'One Sixth',
	'one_sixth_last' => 'One Sixth Last',
	'five_sixth' => 'Five Sixth',
	'five_sixth_last' => 'Five Sixth Last'
);

?>