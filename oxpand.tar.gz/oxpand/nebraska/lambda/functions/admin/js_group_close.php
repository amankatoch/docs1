<?php if (!defined('OT_VERSION')) exit('No direct script access allowed');
/**
 * JavaScript Group Opener
 *
 */
function option_tree_jsgroupclose() 
{
	echo '</div>';
}